package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.Given;
import wrappers.GenericWrappers;

public class ProfilesettupPage extends GenericWrappers{
	public ProfilesettupPage() {
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
		eleIsDisplayed(clicksigninamazon);
	}


	//Click signin
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"sib\"]")
	private WebElement clicksigninamazon;

	@Given("Click SignIn option")
	public ProfilesettupPage Clicksigninamazon() {
		click(clicksigninamazon);
		return this;
	}




}
