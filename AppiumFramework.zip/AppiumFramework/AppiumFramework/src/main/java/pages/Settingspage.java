package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.Given;
import wrappers.GenericWrappers;

public class Settingspage extends GenericWrappers{
	public Settingspage() {
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
		eleIsDisplayed(clkcustomerservice);
	}
	
	//Click customer service option
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ViewSwitcher/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.view.ViewGroup/android.view.View")
	private WebElement clkcustomerservice;
	
	@Given("click customerservice option")
	public Settingspage customerservice() {
		click(clkcustomerservice);
		return this;
	}
	
	//Click prime category
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ViewSwitcher/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup[2]")
	private WebElement clkprimecategory;
	
	@Given("Click prime category")
	public Settingspage clkprimecategory() {
		click(clkprimecategory);
		return this;
	}
	
	
	//Click prime signup button
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.ViewSwitcher/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[4]/android.view.ViewGroup/android.view.ViewGroup/android.view.View[1]")
	private WebElement clkprimesignupbtn;
	
	@Given("Click prime signup button")
	public Primepage primesignupbtn() {
		click(clkprimesignupbtn);
		return new Primepage();
	}
	
	
	
		
	

}
