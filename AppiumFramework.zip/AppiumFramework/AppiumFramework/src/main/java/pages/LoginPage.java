package pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.Given;

import wrappers.GenericWrappers;

public class LoginPage extends GenericWrappers{

	public LoginPage() {
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
		eleIsDisplayed(skipsigninbtn);
	}



	//Skip signin
	@AndroidFindBy(xpath = "com.amazon.mShop.android.shopping:id/skip_sign_in_button")
	private WebElement skipsigninbtn;

	@Given("Click skip signIn button")
	public LoginPage clickshipsignin() {
		click(skipsigninbtn);
		return this;
	}

	//Click profile Icon
	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Your Amazon.com Tab 2 of 4\"]/android.widget.ImageView")
	private WebElement Clkprofileicon;

	@Given("Click Profile Icon")
	public ProfilesettupPage clkprofileicon() {
		click(Clkprofileicon);
		return new ProfilesettupPage();
	}

	//Click Home button
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Home Tab 1 of 4\"]")
	private WebElement clkHomeButton;

	@Given("Click Home Icon")
	public LoginPage clkhomebutton() {
		click(clkHomeButton);
		return this;
	}


	//Click Search Option
	@AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/chrome_search_hint_view")
	private WebElement clksearchoption;

	@Given("Click Search")
	public LoginPage clicksearch() {
		click(clksearchoption);
		return this;
	}


	//Type as Pencils
	@AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/chrome_search_hint_view")
	private WebElement searchaspencils;

	@Given("search as {string}")
	public LoginPage searchaspencils(String product) {
		enterValue(searchaspencils, product);
		return this;

	}

	//Click first search option
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.widget.Button[2]")
	private WebElement selectfirstsearchoption;

	@Given("Choose as first search option")
	public LoginPage firstsearchoption() {
		click(selectfirstsearchoption);
		return this;
	}


	//Click cart option
	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Cart 0 item Tab 3 of 4\"]/android.widget.ImageView")
	private WebElement clkcartoptn;

	@Given("Click cart option")
	public CartPage clickcartoption() {
		click(clkcartoptn);
		return new CartPage();
	}



	//Click Settings option
	@AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Menu. Contains your orders, your account, shop by department, programs and features, settings, and customer service Tab 4 of 4\"]")
	private WebElement clksettingsoptn;

	@Given("Click settings option")
	public Settingspage clicksettingsoptn() {
		click(clksettingsoptn);
		return new Settingspage();
	}



}
