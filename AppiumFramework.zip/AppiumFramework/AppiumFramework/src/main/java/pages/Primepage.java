package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.Given;
import wrappers.GenericWrappers;

public class Primepage extends GenericWrappers{
	public Primepage() {
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
		if(!eleIsDisplayed(verifytxt)){
		throw new RuntimeException("Text is not displayed");
		}
	}
	
	
	//Verify text
		@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View[2]/android.view.View[2]/android.view.View[2]")
		private WebElement verifytxt;
		
		@Given("Verify the text")
		public Primepage verifytxt() {
			eleIsDisplayed(verifytxt);
			return this;
		}
}
