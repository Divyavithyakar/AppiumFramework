package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.Given;
import wrappers.GenericWrappers;

public class CartPage extends GenericWrappers{
	public CartPage() {
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
		eleIsDisplayed(clkcontinueshopping);
	}
	
	
	//Click Continue shopping
	@AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Continue shopping\"]")
	private WebElement clkcontinueshopping;
	
	@Given("click continue shopping")
	public LoginPage clickcontinueshopping() {
		click(clkcontinueshopping);
		return new LoginPage();
	}
	
	

}
